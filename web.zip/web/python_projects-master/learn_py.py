x=0
while x <= 18:
    x= x+3
print(x)